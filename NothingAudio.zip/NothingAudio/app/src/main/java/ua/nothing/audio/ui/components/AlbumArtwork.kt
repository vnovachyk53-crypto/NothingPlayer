package ua.nothing.audio.ui.components

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import ua.nothing.audio.ui.theme.NothingBorder
import ua.nothing.audio.ui.theme.NothingDarkGray
import ua.nothing.audio.ui.theme.NothingGray
import ua.nothing.audio.ui.theme.NothingRed
import java.io.File

private object ArtworkMemoryCache {
    private val cache = object : LruCache<String, ImageBitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: ImageBitmap): Int {
            return value.width * value.height * 4
        }
    }

    fun get(path: String): ImageBitmap? = cache.get(path)
    fun put(path: String, bitmap: ImageBitmap) {
        cache.put(path, bitmap)
    }
}

/**
 * Відображає оригінальну обкладинку треку в чистому вигляді без будь-яких фільтрів.
 */
@Composable
fun AlbumArtwork(
    artworkPath: String?,
    modifier: Modifier = Modifier,
    isActiveTrack: Boolean = false
) {
    val imageBitmap by produceState<ImageBitmap?>(initialValue = artworkPath?.let { ArtworkMemoryCache.get(it) }, key1 = artworkPath) {
        if (artworkPath.isNullOrBlank()) {
            value = null
            return@produceState
        }
        ArtworkMemoryCache.get(artworkPath)?.let {
            value = it
            return@produceState
        }
        value = withContext(Dispatchers.IO) {
            try {
                val file = File(artworkPath)
                if (!file.exists()) return@withContext null
                val bmp: Bitmap = BitmapFactory.decodeFile(file.absolutePath) ?: return@withContext null
                val img = bmp.asImageBitmap()
                ArtworkMemoryCache.put(artworkPath, img)
                img
            } catch (_: Exception) {
                null
            }
        }
    }

    Box(
        modifier = modifier
            .background(NothingDarkGray)
            .border(1.dp, if (isActiveTrack) NothingRed else NothingBorder),
        contentAlignment = Alignment.Center
    ) {
        val loaded = imageBitmap
        if (loaded != null) {
            Image(
                bitmap = loaded,
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else {
            // Мінімалістична геометрична заглушка Nothing OS
            Canvas(modifier = Modifier.size(24.dp)) {
                val r = size.minDimension / 2f
                drawCircle(
                    color = NothingGray,
                    radius = r,
                    style = Stroke(width = 1.5.dp.toPx())
                )
                drawCircle(
                    color = if (isActiveTrack) NothingRed else NothingGray,
                    radius = r * 0.25f
                )
            }
        }
    }
}
