package ua.nothing.audio.player

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.common.Timeline
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import ua.nothing.audio.data.db.TrackEntity
import ua.nothing.audio.service.PlaybackService

data class QueueItem(
    val queueIndex: Int,
    val trackId: Long,
    val title: String,
    val artist: String,
    val uriString: String,
    val artworkPath: String?,
    val durationMs: Long
)

data class PlaybackUiState(
    val currentTrack: QueueItem? = null,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
    val shuffleEnabled: Boolean = false,
    val queue: List<QueueItem> = emptyList(),
    val currentQueueIndex: Int = -1
)

class PlayerController(context: Context) {

    private val appContext = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private var progressJob: Job? = null

    private val _state = MutableStateFlow(PlaybackUiState())
    val state: StateFlow<PlaybackUiState> = _state.asStateFlow()

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            syncState()
            if (isPlaying) startProgressPolling() else stopProgressPolling()
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            syncState()
        }

        override fun onTimelineChanged(timeline: Timeline, reason: Int) {
            syncState()
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            syncState()
        }

        override fun onRepeatModeChanged(repeatMode: Int) {
            syncState()
        }

        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
            syncState()
        }
    }

    init {
        val token = SessionToken(
            appContext,
            ComponentName(appContext, PlaybackService::class.java)
        )
        val future = MediaController.Builder(appContext, token).buildAsync()
        controllerFuture = future
        future.addListener(
            {
                try {
                    val mc = future.get()
                    controller = mc
                    mc.addListener(listener)
                    syncState()
                    if (mc.isPlaying) startProgressPolling()
                } catch (_: Exception) {
                }
            },
            ContextCompat.getMainExecutor(appContext)
        )
    }

    fun playTracks(tracks: List<TrackEntity>, startIndex: Int = 0) {
        val mc = controller ?: return
        if (tracks.isEmpty()) return
        val safeIndex = startIndex.coerceIn(0, tracks.lastIndex)
        val mediaItems = tracks.map { it.toMediaItem() }
        mc.setMediaItems(mediaItems, safeIndex, 0L)
        mc.prepare()
        mc.play()
        syncState()
    }

    fun playNext(track: TrackEntity) {
        val mc = controller ?: return
        if (mc.mediaItemCount == 0) {
            playTracks(listOf(track), 0)
            return
        }
        val insertIndex = (mc.currentMediaItemIndex + 1).coerceIn(0, mc.mediaItemCount)
        mc.addMediaItem(insertIndex, track.toMediaItem())
        syncState()
    }

    fun appendToQueue(track: TrackEntity) {
        val mc = controller ?: return
        if (mc.mediaItemCount == 0) {
            playTracks(listOf(track), 0)
            return
        }
        mc.addMediaItem(track.toMediaItem())
        syncState()
    }

    fun togglePlayPause() {
        val mc = controller ?: return
        if (mc.isPlaying) {
            mc.pause()
        } else {
            if (mc.playbackState == Player.STATE_IDLE && mc.mediaItemCount > 0) {
                mc.prepare()
            }
            mc.play()
        }
        syncState()
    }

    fun skipNext() {
        val mc = controller ?: return
        if (mc.hasNextMediaItem()) {
            mc.seekToNextMediaItem()
        } else if (mc.mediaItemCount > 0) {
            mc.seekToDefaultPosition(0)
        }
        syncState()
    }

    fun skipPrevious() {
        val mc = controller ?: return
        if (mc.currentPosition > 3500L) {
            mc.seekTo(0L)
        } else if (mc.hasPreviousMediaItem()) {
            mc.seekToPreviousMediaItem()
        } else if (mc.mediaItemCount > 0) {
            mc.seekTo(0L)
        }
        syncState()
    }

    fun seekTo(positionMs: Long) {
        val mc = controller ?: return
        mc.seekTo(positionMs.coerceAtLeast(0L))
        _state.update { it.copy(positionMs = positionMs.coerceAtLeast(0L)) }
    }

    fun cycleRepeatMode() {
        val mc = controller ?: return
        val nextMode = when (mc.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
        mc.repeatMode = nextMode
        syncState()
    }

    fun toggleShuffle() {
        val mc = controller ?: return
        mc.shuffleModeEnabled = !mc.shuffleModeEnabled
        syncState()
    }

    fun jumpToQueueIndex(index: Int) {
        val mc = controller ?: return
        if (index in 0 until mc.mediaItemCount) {
            mc.seekToDefaultPosition(index)
            mc.prepare()
            mc.play()
            syncState()
        }
    }

    fun moveQueueItem(fromIndex: Int, toIndex: Int) {
        val mc = controller ?: return
        if (fromIndex == toIndex) return
        if (fromIndex !in 0 until mc.mediaItemCount || toIndex !in 0 until mc.mediaItemCount) return
        mc.moveMediaItem(fromIndex, toIndex)
        syncState()
    }

    fun removeQueueItem(index: Int) {
        val mc = controller ?: return
        if (index !in 0 until mc.mediaItemCount) return
        mc.removeMediaItem(index)
        syncState()
    }

    private fun startProgressPolling() {
        if (progressJob?.isActive == true) return
        progressJob = scope.launch {
            while (isActive) {
                val mc = controller
                if (mc != null && mc.isPlaying) {
                    val dur = mc.duration.takeIf { it > 0L } ?: _state.value.durationMs
                    _state.update {
                        it.copy(
                            positionMs = mc.currentPosition.coerceAtLeast(0L),
                            durationMs = dur
                        )
                    }
                }
                delay(200L)
            }
        }
    }

    private fun stopProgressPolling() {
        progressJob?.cancel()
        progressJob = null
    }

    private fun syncState() {
        val mc = controller ?: return
        val count = mc.mediaItemCount
        val queueList = ArrayList<QueueItem>(count)
        for (i in 0 until count) {
            queueList.add(mc.getMediaItemAt(i).toQueueItem(i))
        }
        val currentIndex = mc.currentMediaItemIndex.takeIf { it in 0 until count } ?: -1
        val currentItem = if (currentIndex >= 0) queueList[currentIndex] else null
        val duration = mc.duration.takeIf { it > 0L }
            ?: currentItem?.durationMs
            ?: 0L

        _state.update {
            it.copy(
                currentTrack = currentItem,
                isPlaying = mc.isPlaying,
                positionMs = mc.currentPosition.coerceAtLeast(0L),
                durationMs = duration,
                repeatMode = mc.repeatMode,
                shuffleEnabled = mc.shuffleModeEnabled,
                queue = queueList,
                currentQueueIndex = currentIndex
            )
        }
    }

    fun release() {
        stopProgressPolling()
        controller?.removeListener(listener)
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controller = null
    }

    private fun TrackEntity.toMediaItem(): MediaItem {
        val extras = Bundle().apply {
            putLong(PlaybackService.EXTRA_TRACK_ID, id)
            putString(PlaybackService.EXTRA_ARTWORK_PATH, artworkPath)
            putLong(PlaybackService.EXTRA_DURATION_MS, durationMs)
        }
        val metadata = MediaMetadata.Builder()
            .setTitle(title)
            .setArtist(artist)
            .setExtras(extras)
            .build()

        return MediaItem.Builder()
            .setMediaId(id.toString())
            .setUri(Uri.parse(uriString))
            .setMediaMetadata(metadata)
            .build()
    }

    private fun MediaItem.toQueueItem(index: Int): QueueItem {
        val extras = mediaMetadata.extras
        return QueueItem(
            queueIndex = index,
            trackId = extras?.getLong(PlaybackService.EXTRA_TRACK_ID, -1L) ?: -1L,
            title = mediaMetadata.title?.toString() ?: "Без назви",
            artist = mediaMetadata.artist?.toString() ?: "Невідомий виконавець",
            uriString = localConfiguration?.uri?.toString().orEmpty(),
            artworkPath = extras?.getString(PlaybackService.EXTRA_ARTWORK_PATH),
            durationMs = extras?.getLong(PlaybackService.EXTRA_DURATION_MS, 0L) ?: 0L
        )
    }
}
