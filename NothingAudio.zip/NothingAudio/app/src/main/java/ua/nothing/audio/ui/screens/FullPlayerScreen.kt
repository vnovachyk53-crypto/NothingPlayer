package ua.nothing.audio.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.QueueMusic
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DragHandle
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import androidx.media3.common.Player
import ua.nothing.audio.player.PlaybackUiState
import ua.nothing.audio.player.QueueItem
import ua.nothing.audio.ui.components.AlbumArtwork
import ua.nothing.audio.ui.components.DotMatrixText
import ua.nothing.audio.ui.theme.NothingBlack
import ua.nothing.audio.ui.theme.NothingBorder
import ua.nothing.audio.ui.theme.NothingDarkGray
import ua.nothing.audio.ui.theme.NothingGray
import ua.nothing.audio.ui.theme.NothingRed
import ua.nothing.audio.ui.theme.NothingWhite
import ua.nothing.audio.ui.theme.formatDuration
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FullPlayerScreen(
    playbackState: PlaybackUiState,
    onCollapse: () -> Unit,
    onPrevious: () -> Unit,
    onTogglePlayPause: () -> Unit,
    onNext: () -> Unit,
    onSeekTo: (Long) -> Unit,
    onCycleRepeat: () -> Unit,
    onToggleShuffle: () -> Unit,
    onJumpToQueueIndex: (Int) -> Unit,
    onMoveQueueItem: (Int, Int) -> Unit,
    onRemoveQueueItem: (Int) -> Unit
) {
    val track = playbackState.currentTrack
    var showQueueSheet by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NothingBlack)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Верхня панель навігації
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .background(NothingBlack)
                    .border(1.dp, NothingBorder)
                    .clickable { onCollapse() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.KeyboardArrowDown,
                    contentDescription = "Згорнути",
                    tint = NothingWhite,
                    modifier = Modifier.size(26.dp)
                )
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                DotMatrixText(
                    text = "ВІДТВОРЕННЯ",
                    color = NothingWhite,
                    dotSize = 2.dp,
                    dotGap = 1.dp
                )
                Spacer(modifier = Modifier.height(4.dp))
                val posLabel = if (playbackState.currentQueueIndex >= 0) {
                    "%02d / %02d".format(playbackState.currentQueueIndex + 1, playbackState.queue.size)
                } else {
                    "00 / 00"
                }
                Text(
                    text = "ТРЕК $posLabel",
                    style = MaterialTheme.typography.labelSmall,
                    color = NothingGray
                )
            }

            Box(
                modifier = Modifier
                    .size(44.dp)
                    .background(if (showQueueSheet) NothingRed else NothingBlack)
                    .border(1.dp, NothingBorder)
                    .clickable { showQueueSheet = true },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.QueueMusic,
                    contentDescription = "Черга",
                    tint = NothingWhite,
                    modifier = Modifier.size(22.dp)
                )
            }
        }

        // Чиста обкладинка треку без фільтрів
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            contentAlignment = Alignment.Center
        ) {
            AlbumArtwork(
                artworkPath = track?.artworkPath,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f),
                isActiveTrack = playbackState.isPlaying
            )
        }

        // Інформація про трек, повзунок та кнопки керування
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = track?.title ?: "Трек не вибрано",
                    style = MaterialTheme.typography.titleLarge,
                    color = NothingWhite,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = track?.artist ?: "—",
                    style = MaterialTheme.typography.bodyLarge,
                    color = NothingGray,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // Точний повзунок перемотування + таймери у стилі Nothing OS
            NothingSeekBar(
                positionMs = playbackState.positionMs,
                durationMs = playbackState.durationMs,
                onSeekTo = onSeekTo
            )

            // Головні кнопки керування відтворенням
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Шафл
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .background(if (playbackState.shuffleEnabled) NothingRed else NothingBlack)
                        .border(1.dp, if (playbackState.shuffleEnabled) NothingRed else NothingBorder)
                        .clickable { onToggleShuffle() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Shuffle,
                        contentDescription = "Перемішати",
                        tint = if (playbackState.shuffleEnabled) NothingWhite else NothingGray,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Попередній
                Box(
                    modifier = Modifier
                        .size(58.dp)
                        .background(NothingBlack)
                        .border(1.dp, NothingBorder)
                        .clickable { onPrevious() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.SkipPrevious,
                        contentDescription = "Попередній",
                        tint = NothingWhite,
                        modifier = Modifier.size(28.dp)
                    )
                }

                // Пауза / Плей
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .background(NothingRed)
                        .border(1.dp, NothingRed)
                        .clickable { onTogglePlayPause() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (playbackState.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = if (playbackState.isPlaying) "Пауза" else "Відтворити",
                        tint = NothingWhite,
                        modifier = Modifier.size(36.dp)
                    )
                }

                // Наступний
                Box(
                    modifier = Modifier
                        .size(58.dp)
                        .background(NothingBlack)
                        .border(1.dp, NothingBorder)
                        .clickable { onNext() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.SkipNext,
                        contentDescription = "Наступний",
                        tint = NothingWhite,
                        modifier = Modifier.size(28.dp)
                    )
                }

                // Повтор (вимкнено / весь список / один трек)
                val repeatActive = playbackState.repeatMode != Player.REPEAT_MODE_OFF
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .background(if (repeatActive) NothingRed else NothingBlack)
                        .border(1.dp, if (repeatActive) NothingRed else NothingBorder)
                        .clickable { onCycleRepeat() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (playbackState.repeatMode == Player.REPEAT_MODE_ONE) {
                            Icons.Filled.RepeatOne
                        } else {
                            Icons.Filled.Repeat
                        },
                        contentDescription = "Режим повтору",
                        tint = if (repeatActive) NothingWhite else NothingGray,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }

    if (showQueueSheet) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = { showQueueSheet = false },
            sheetState = sheetState,
            shape = RectangleShape,
            containerColor = NothingBlack,
            contentColor = NothingWhite,
            dragHandle = {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(NothingBlack)
                        .border(1.dp, NothingBorder)
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(width = 40.dp, height = 3.dp)
                            .background(NothingGray)
                    )
                }
            }
        ) {
            QueueSheetContent(
                queue = playbackState.queue,
                currentQueueIndex = playbackState.currentQueueIndex,
                onSelectTrack = { index ->
                    onJumpToQueueIndex(index)
                },
                onMoveItem = onMoveQueueItem,
                onRemoveItem = onRemoveQueueItem
            )
        }
    }
}

@Composable
private fun NothingSeekBar(
    positionMs: Long,
    durationMs: Long,
    onSeekTo: (Long) -> Unit
) {
    var isDragging by remember { mutableStateOf(false) }
    var dragFraction by remember { mutableFloatStateOf(0f) }

    val liveFraction = if (durationMs > 0L) {
        (positionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
    } else {
        0f
    }
    val displayFraction = if (isDragging) dragFraction else liveFraction
    val displayPositionMs = if (isDragging) {
        (dragFraction * durationMs).toLong()
    } else {
        positionMs
    }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(28.dp)
                .pointerInput(durationMs) {
                    detectTapGestures { offset ->
                        if (durationMs > 0L && size.width > 0) {
                            val fraction = (offset.x / size.width.toFloat()).coerceIn(0f, 1f)
                            onSeekTo((fraction * durationMs).toLong())
                        }
                    }
                }
                .pointerInput(durationMs) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            if (durationMs > 0L && size.width > 0) {
                                isDragging = true
                                dragFraction = (offset.x / size.width.toFloat()).coerceIn(0f, 1f)
                            }
                        },
                        onDrag = { change, _ ->
                            change.consume()
                            if (durationMs > 0L && size.width > 0) {
                                dragFraction = (change.position.x / size.width.toFloat()).coerceIn(0f, 1f)
                            }
                        },
                        onDragEnd = {
                            if (isDragging && durationMs > 0L) {
                                onSeekTo((dragFraction * durationMs).toLong())
                            }
                            isDragging = false
                        },
                        onDragCancel = {
                            isDragging = false
                        }
                    )
                }
        ) {
            val trackHeight = 3.dp.toPx()
            val centerY = size.height / 2f
            val activeWidth = size.width * displayFraction

            // Неактивна доріжка
            drawRect(
                color = NothingBorder,
                topLeft = Offset(0f, centerY - trackHeight / 2f),
                size = Size(size.width, trackHeight)
            )

            // Активна червона доріжка
            drawRect(
                color = NothingRed,
                topLeft = Offset(0f, centerY - trackHeight / 2f),
                size = Size(activeWidth, trackHeight)
            )

            // Геометричний прямокутний повзунок Nothing
            val thumbWidth = 10.dp.toPx()
            val thumbHeight = 18.dp.toPx()
            val thumbX = (activeWidth - thumbWidth / 2f).coerceIn(0f, size.width - thumbWidth)
            drawRect(
                color = NothingWhite,
                topLeft = Offset(thumbX, centerY - thumbHeight / 2f),
                size = Size(thumbWidth, thumbHeight)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            DotMatrixText(
                text = formatDuration(displayPositionMs),
                color = NothingWhite,
                dotSize = 2.dp,
                dotGap = 1.dp
            )
            DotMatrixText(
                text = formatDuration(durationMs),
                color = NothingGray,
                dotSize = 2.dp,
                dotGap = 1.dp
            )
        }
    }
}

@Composable
private fun QueueSheetContent(
    queue: List<QueueItem>,
    currentQueueIndex: Int,
    onSelectTrack: (Int) -> Unit,
    onMoveItem: (Int, Int) -> Unit,
    onRemoveItem: (Int) -> Unit
) {
    val itemHeightDp = 64.dp
    val itemHeightPx = with(LocalDensity.current) { itemHeightDp.toPx() }
    var draggingIndex by remember { mutableIntStateOf(-1) }
    var dragOffsetY by remember { mutableFloatStateOf(0f) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(NothingBlack)
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            DotMatrixText(
                text = "ЧЕРГА ВІДТВОРЕННЯ",
                color = NothingWhite,
                dotSize = 2.dp,
                dotGap = 1.dp
            )
            Text(
                text = "${queue.size} ТРЕКІВ",
                style = MaterialTheme.typography.labelSmall,
                color = NothingRed
            )
        }

        if (queue.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
                    .border(1.dp, NothingBorder),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "ЧЕРГА ПОРОЖНЯ",
                    style = MaterialTheme.typography.bodyMedium,
                    color = NothingGray
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(420.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                itemsIndexed(
                    items = queue,
                    key = { index, item -> "${item.trackId}_$index" }
                ) { index, item ->
                    val isCurrent = index == currentQueueIndex
                    val isDragging = index == draggingIndex

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(itemHeightDp)
                            .zIndex(if (isDragging) 10f else 0f)
                            .offset {
                                IntOffset(0, if (isDragging) dragOffsetY.roundToInt() else 0)
                            }
                            .background(if (isDragging) NothingDarkGray else NothingBlack)
                            .border(1.dp, if (isCurrent || isDragging) NothingRed else NothingBorder)
                            .clickable { onSelectTrack(index) }
                            .padding(horizontal = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Ручка перетягування треку в черзі
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .pointerInput(index, queue.size) {
                                    detectDragGestures(
                                        onDragStart = {
                                            draggingIndex = index
                                            dragOffsetY = 0f
                                        },
                                        onDrag = { change, dragAmount ->
                                            change.consume()
                                            dragOffsetY += dragAmount.y
                                        },
                                        onDragEnd = {
                                            if (draggingIndex in queue.indices) {
                                                val deltaSteps = (dragOffsetY / itemHeightPx).roundToInt()
                                                val target = (draggingIndex + deltaSteps)
                                                    .coerceIn(0, queue.lastIndex)
                                                if (target != draggingIndex) {
                                                    onMoveItem(draggingIndex, target)
                                                }
                                            }
                                            draggingIndex = -1
                                            dragOffsetY = 0f
                                        },
                                        onDragCancel = {
                                            draggingIndex = -1
                                            dragOffsetY = 0f
                                        }
                                    )
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.DragHandle,
                                contentDescription = "Перетягнути",
                                tint = if (isDragging) NothingRed else NothingGray,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Text(
                            text = "%02d".format(index + 1),
                            style = MaterialTheme.typography.labelLarge,
                            color = if (isCurrent) NothingRed else NothingGray
                        )

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = item.title,
                                style = MaterialTheme.typography.titleMedium,
                                color = if (isCurrent) NothingRed else NothingWhite,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = item.artist,
                                style = MaterialTheme.typography.bodyMedium,
                                color = NothingGray,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clickable { onRemoveItem(index) },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Close,
                                contentDescription = "Видалити з черги",
                                tint = NothingGray,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
