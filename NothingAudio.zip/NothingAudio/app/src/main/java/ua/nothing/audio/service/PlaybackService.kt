package ua.nothing.audio.service

import android.content.Intent
import android.os.Bundle
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import java.io.File

class PlaybackService : MediaSessionService() {

    private var mediaSession: MediaSession? = null
    private lateinit var player: ExoPlayer

    private val playerListener = object : Player.Listener {
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            attachArtworkToActiveItem(mediaItem)
        }
    }

    @OptIn(UnstableApi::class)
    override fun onCreate() {
        super.onCreate()

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()

        player = ExoPlayer.Builder(this)
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .build()

        player.addListener(playerListener)

        mediaSession = MediaSession.Builder(this, player)
            .build()
    }

    private fun attachArtworkToActiveItem(mediaItem: MediaItem?) {
        val item = mediaItem ?: return
        val extras = item.mediaMetadata.extras ?: return
        val artworkPath = extras.getString(EXTRA_ARTWORK_PATH) ?: return
        if (item.mediaMetadata.artworkData != null) return

        val file = File(artworkPath)
        if (!file.exists()) return

        try {
            val bytes = file.readBytes()
            val updatedMetadata = item.mediaMetadata.buildUpon()
                .setArtworkData(bytes, MediaMetadata.PICTURE_TYPE_FRONT_COVER)
                .build()
            val updatedItem = item.buildUpon()
                .setMediaMetadata(updatedMetadata)
                .build()
            val index = player.currentMediaItemIndex
            if (index in 0 until player.mediaItemCount) {
                player.replaceMediaItem(index, updatedItem)
            }
        } catch (_: Exception) {
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
        return mediaSession
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        val currentPlayer = mediaSession?.player
        if (currentPlayer == null || !currentPlayer.playWhenReady || currentPlayer.mediaItemCount == 0) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        player.removeListener(playerListener)
        mediaSession?.run {
            player.release()
            release()
            mediaSession = null
        }
        super.onDestroy()
    }

    companion object {
        const val EXTRA_TRACK_ID = "extra_track_id"
        const val EXTRA_ARTWORK_PATH = "extra_artwork_path"
        const val EXTRA_DURATION_MS = "extra_duration_ms"

        fun Bundle.getTrackId(): Long = getLong(EXTRA_TRACK_ID, -1L)
    }
}
