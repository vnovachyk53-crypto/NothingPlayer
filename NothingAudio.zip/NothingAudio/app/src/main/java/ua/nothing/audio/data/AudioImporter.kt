package ua.nothing.audio.data

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import ua.nothing.audio.data.db.TrackEntity
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest

class AudioImporter(private val context: Context) {

    private val supportedExtensions = setOf(
        "mp3", "flac", "wav", "ogg", "m4a", "aac", "opus", "wma", "alac", "aiff"
    )

    private val artworkDir: File by lazy {
        File(context.filesDir, "artwork").apply { mkdirs() }
    }

    suspend fun importDocumentUris(uris: List<Uri>): List<TrackEntity> = withContext(Dispatchers.IO) {
        val result = mutableListOf<TrackEntity>()
        for (uri in uris) {
            takePersistableReadPermission(uri)
            extractTrackEntity(uri, fallbackName = queryDisplayName(uri))?.let {
                result.add(it)
            }
        }
        result
    }

    suspend fun importTreeUri(treeUri: Uri): List<TrackEntity> = withContext(Dispatchers.IO) {
        takePersistableReadPermission(treeUri)
        val rootDoc = DocumentFile.fromTreeUri(context, treeUri) ?: return@withContext emptyList()
        val audioDocs = mutableListOf<DocumentFile>()
        collectAudioDocuments(rootDoc, audioDocs)

        val result = mutableListOf<TrackEntity>()
        for (doc in audioDocs) {
            extractTrackEntity(doc.uri, fallbackName = doc.name)?.let {
                result.add(it)
            }
        }
        result
    }

    private fun takePersistableReadPermission(uri: Uri) {
        try {
            context.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (_: SecurityException) {
            // Ігноруємо, якщо провайдер не вимагає або не підтримує постійний дозвіл для дочірнього елемента
        }
    }

    private fun collectAudioDocuments(dir: DocumentFile, out: MutableList<DocumentFile>) {
        if (!dir.canRead()) return
        val children = dir.listFiles()
        for (child in children) {
            if (child.isDirectory) {
                collectAudioDocuments(child, out)
            } else if (child.isFile && isAudioDocument(child)) {
                out.add(child)
            }
        }
    }

    private fun isAudioDocument(doc: DocumentFile): Boolean {
        val mime = doc.type
        if (mime != null && mime.startsWith("audio/")) return true
        val ext = doc.name?.substringAfterLast('.', "")?.lowercase().orEmpty()
        return ext in supportedExtensions
    }

    private fun extractTrackEntity(uri: Uri, fallbackName: String?): TrackEntity? {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)

            val rawTitle = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
            val rawArtist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
            val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)

            val durationMs = durationStr?.toLongOrNull() ?: 0L
            val cleanFallback = fallbackName
                ?.substringBeforeLast('.')
                ?.takeIf { it.isNotBlank() }
                ?: "Без назви"

            val title = rawTitle?.trim()?.takeIf { it.isNotEmpty() } ?: cleanFallback
            val artist = rawArtist?.trim()?.takeIf { it.isNotEmpty() } ?: "Невідомий виконавець"

            val artworkBytes = retriever.embeddedPicture
            val artworkPath = if (artworkBytes != null && artworkBytes.isNotEmpty()) {
                saveArtworkToCache(uri.toString(), artworkBytes)
            } else {
                null
            }

            TrackEntity(
                uriString = uri.toString(),
                title = title,
                artist = artist,
                durationMs = durationMs,
                artworkPath = artworkPath
            )
        } catch (_: Exception) {
            null
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {
            }
        }
    }

    private fun saveArtworkToCache(uriKey: String, data: ByteArray): String? {
        return try {
            val hash = sha256(uriKey)
            val targetFile = File(artworkDir, "$hash.jpg")
            if (targetFile.exists() && targetFile.length() > 0L) {
                return targetFile.absolutePath
            }

            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(data, 0, data.size, options)

            val maxDim = 640
            var sampleSize = 1
            while (options.outWidth / sampleSize > maxDim || options.outHeight / sampleSize > maxDim) {
                sampleSize *= 2
            }

            val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sampleSize }
            val bitmap = BitmapFactory.decodeByteArray(data, 0, data.size, decodeOpts)
                ?: return null

            FileOutputStream(targetFile).use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 88, out)
            }
            bitmap.recycle()
            targetFile.absolutePath
        } catch (_: Exception) {
            null
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        return try {
            context.contentResolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) cursor.getString(idx) else null
                } else {
                    null
                }
            }
        } catch (_: Exception) {
            uri.lastPathSegment
        }
    }

    private fun sha256(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return digest.joinToString("") { "%02x".format(it) }.take(24)
    }
}
