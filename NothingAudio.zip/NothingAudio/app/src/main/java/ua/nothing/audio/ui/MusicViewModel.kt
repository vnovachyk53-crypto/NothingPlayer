package ua.nothing.audio.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import ua.nothing.audio.NothingAudioApp
import ua.nothing.audio.data.db.PlaylistSummary
import ua.nothing.audio.data.db.TrackEntity
import ua.nothing.audio.player.PlaybackUiState

class MusicViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as NothingAudioApp
    private val repository = app.repository
    val playerController = app.playerController

    val allTracks: StateFlow<List<TrackEntity>> = repository.allTracks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val playlists: StateFlow<List<PlaylistSummary>> = repository.playlists
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val playbackState: StateFlow<PlaybackUiState> = playerController.state

    private val _isImporting = MutableStateFlow(false)
    val isImporting: StateFlow<Boolean> = _isImporting.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    fun importFiles(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            _isImporting.value = true
            val count = repository.importFiles(uris)
            _isImporting.value = false
            _statusMessage.value = if (count > 0) {
                "Додано треків: $count"
            } else {
                "Нових аудіофайлів не знайдено"
            }
        }
    }

    fun importFolder(treeUri: Uri?) {
        if (treeUri == null) return
        viewModelScope.launch {
            _isImporting.value = true
            val count = repository.importFolder(treeUri)
            _isImporting.value = false
            _statusMessage.value = if (count > 0) {
                "Імпортовано з папки: $count"
            } else {
                "У папці не знайдено нових треків"
            }
        }
    }

    fun deleteTrack(track: TrackEntity) {
        viewModelScope.launch {
            repository.removeTrack(track)
            _statusMessage.value = "Видалено: ${track.title}"
        }
    }

    fun createPlaylist(name: String) {
        viewModelScope.launch {
            val id = repository.createPlaylist(name)
            if (id > 0L) {
                _statusMessage.value = "Плейлист створено"
            }
        }
    }

    fun deletePlaylist(playlistId: Long) {
        viewModelScope.launch {
            repository.deletePlaylist(playlistId)
            _statusMessage.value = "Плейлист видалено"
        }
    }

    fun observePlaylistTracks(playlistId: Long) = repository.observePlaylistTracks(playlistId)

    fun addTrackToPlaylist(playlistId: Long, trackId: Long) {
        viewModelScope.launch {
            repository.addTrackToPlaylist(playlistId, trackId)
            _statusMessage.value = "Додано до плейлиста"
        }
    }

    fun addTracksToPlaylist(playlistId: Long, trackIds: List<Long>) {
        if (trackIds.isEmpty()) return
        viewModelScope.launch {
            repository.addTracksToPlaylist(playlistId, trackIds)
            _statusMessage.value = "Додано треків: ${trackIds.size}"
        }
    }

    fun removeTrackFromPlaylist(playlistId: Long, trackId: Long) {
        viewModelScope.launch {
            repository.removeTrackFromPlaylist(playlistId, trackId)
        }
    }

    fun playAllTracks(startIndex: Int = 0) {
        val list = allTracks.value
        if (list.isNotEmpty()) {
            playerController.playTracks(list, startIndex)
        }
    }

    fun playPlaylist(playlistId: Long, startIndex: Int = 0) {
        viewModelScope.launch {
            val tracks = repository.getPlaylistTracksOnce(playlistId)
            if (tracks.isNotEmpty()) {
                playerController.playTracks(tracks, startIndex)
            }
        }
    }
}
