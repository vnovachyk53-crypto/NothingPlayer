package ua.nothing.audio.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ua.nothing.audio.player.PlaybackUiState
import ua.nothing.audio.ui.theme.NothingBlack
import ua.nothing.audio.ui.theme.NothingBorder
import ua.nothing.audio.ui.theme.NothingGray
import ua.nothing.audio.ui.theme.NothingRed
import ua.nothing.audio.ui.theme.NothingWhite

@Composable
fun MiniPlayer(
    playbackState: PlaybackUiState,
    onOpenFullPlayer: () -> Unit,
    onPrevious: () -> Unit,
    onTogglePlayPause: () -> Unit,
    onNext: () -> Unit,
    modifier: Modifier = Modifier
) {
    val track = playbackState.currentTrack ?: return
    val progress = if (playbackState.durationMs > 0L) {
        (playbackState.positionMs.toFloat() / playbackState.durationMs.toFloat()).coerceIn(0f, 1f)
    } else {
        0f
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(NothingBlack)
            .border(1.dp, NothingBorder)
            .clickable { onOpenFullPlayer() }
    ) {
        // Тонка червона смуга прогресу зверху міні-плеєра
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(2.dp)
                .background(NothingBorder)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(progress)
                    .fillMaxHeight()
                    .background(NothingRed)
            )
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            AlbumArtwork(
                artworkPath = track.artworkPath,
                modifier = Modifier.size(42.dp),
                isActiveTrack = playbackState.isPlaying
            )

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Text(
                    text = track.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = NothingWhite,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = track.artist,
                    style = MaterialTheme.typography.bodyMedium,
                    color = NothingGray,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Row(
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ControlSquareButton(
                    onClick = onPrevious,
                    isAccent = false
                ) {
                    Icon(
                        imageVector = Icons.Filled.SkipPrevious,
                        contentDescription = "Попередній",
                        tint = NothingWhite,
                        modifier = Modifier.size(20.dp)
                    )
                }

                ControlSquareButton(
                    onClick = onTogglePlayPause,
                    isAccent = true
                ) {
                    Icon(
                        imageVector = if (playbackState.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = if (playbackState.isPlaying) "Пауза" else "Відтворити",
                        tint = NothingWhite,
                        modifier = Modifier.size(22.dp)
                    )
                }

                ControlSquareButton(
                    onClick = onNext,
                    isAccent = false
                ) {
                    Icon(
                        imageVector = Icons.Filled.SkipNext,
                        contentDescription = "Наступний",
                        tint = NothingWhite,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun ControlSquareButton(
    onClick: () -> Unit,
    isAccent: Boolean,
    content: @Composable () -> Unit
) {
    Box(
        modifier = Modifier
            .size(38.dp)
            .background(if (isAccent) NothingRed else NothingBlack)
            .border(1.dp, if (isAccent) NothingRed else NothingBorder)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        content()
    }
}
