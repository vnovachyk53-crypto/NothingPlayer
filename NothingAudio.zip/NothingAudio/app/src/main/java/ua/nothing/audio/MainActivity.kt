package ua.nothing.audio

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import ua.nothing.audio.ui.MusicViewModel
import ua.nothing.audio.ui.screens.MainScreen
import ua.nothing.audio.ui.theme.NothingAudioTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.BLACK),
            navigationBarStyle = SystemBarStyle.dark(Color.BLACK)
        )

        setContent {
            NothingAudioTheme {
                val musicViewModel: MusicViewModel = viewModel()
                MainScreen(viewModel = musicViewModel)
            }
        }
    }
}
