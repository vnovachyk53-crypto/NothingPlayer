package ua.nothing.audio.data

import android.net.Uri
import kotlinx.coroutines.flow.Flow
import ua.nothing.audio.data.db.AudioDao
import ua.nothing.audio.data.db.PlaylistEntity
import ua.nothing.audio.data.db.PlaylistSummary
import ua.nothing.audio.data.db.PlaylistTrackCrossRef
import ua.nothing.audio.data.db.TrackEntity
import java.io.File

class AudioRepository(
    private val dao: AudioDao,
    private val importer: AudioImporter
) {
    val allTracks: Flow<List<TrackEntity>> = dao.observeAllTracks()
    val playlists: Flow<List<PlaylistSummary>> = dao.observePlaylists()

    fun observePlaylistTracks(playlistId: Long): Flow<List<TrackEntity>> =
        dao.observePlaylistTracks(playlistId)

    suspend fun getPlaylistTracksOnce(playlistId: Long): List<TrackEntity> =
        dao.getPlaylistTracksOnce(playlistId)

    suspend fun importFiles(uris: List<Uri>): Int {
        val tracks = importer.importDocumentUris(uris)
        if (tracks.isEmpty()) return 0
        val inserted = dao.insertTracks(tracks)
        return inserted.count { it != -1L }
    }

    suspend fun importFolder(treeUri: Uri): Int {
        val tracks = importer.importTreeUri(treeUri)
        if (tracks.isEmpty()) return 0
        val inserted = dao.insertTracks(tracks)
        return inserted.count { it != -1L }
    }

    suspend fun removeTrack(track: TrackEntity) {
        dao.deleteTrackById(track.id)
        track.artworkPath?.let { path ->
            try {
                File(path).delete()
            } catch (_: Exception) {
            }
        }
    }

    suspend fun createPlaylist(name: String): Long {
        val trimmed = name.trim()
        if (trimmed.isEmpty()) return -1L
        return dao.insertPlaylist(PlaylistEntity(name = trimmed))
    }

    suspend fun deletePlaylist(playlistId: Long) {
        dao.deletePlaylistById(playlistId)
    }

    suspend fun addTrackToPlaylist(playlistId: Long, trackId: Long) {
        val nextPos = dao.getMaxPositionInPlaylist(playlistId) + 1
        dao.insertPlaylistTrackRef(
            PlaylistTrackCrossRef(
                playlistId = playlistId,
                trackId = trackId,
                position = nextPos
            )
        )
    }

    suspend fun addTracksToPlaylist(playlistId: Long, trackIds: List<Long>) {
        var pos = dao.getMaxPositionInPlaylist(playlistId) + 1
        for (trackId in trackIds) {
            val res = dao.insertPlaylistTrackRef(
                PlaylistTrackCrossRef(
                    playlistId = playlistId,
                    trackId = trackId,
                    position = pos
                )
            )
            if (res != -1L) pos++
        }
    }

    suspend fun removeTrackFromPlaylist(playlistId: Long, trackId: Long) {
        dao.removeTrackFromPlaylist(playlistId, trackId)
    }
}
