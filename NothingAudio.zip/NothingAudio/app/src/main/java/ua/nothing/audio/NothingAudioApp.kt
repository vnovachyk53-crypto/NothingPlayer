package ua.nothing.audio

import android.app.Application
import ua.nothing.audio.data.AudioImporter
import ua.nothing.audio.data.AudioRepository
import ua.nothing.audio.data.db.AppDatabase
import ua.nothing.audio.player.PlayerController

class NothingAudioApp : Application() {

    lateinit var repository: AudioRepository
        private set

    lateinit var playerController: PlayerController
        private set

    override fun onCreate() {
        super.onCreate()
        val database = AppDatabase.getInstance(this)
        val importer = AudioImporter(this)
        repository = AudioRepository(database.audioDao(), importer)
        playerController = PlayerController(this)
    }
}
