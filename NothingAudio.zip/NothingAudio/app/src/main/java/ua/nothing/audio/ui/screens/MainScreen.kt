package ua.nothing.audio.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import ua.nothing.audio.data.db.PlaylistSummary
import ua.nothing.audio.data.db.TrackEntity
import ua.nothing.audio.ui.MusicViewModel
import ua.nothing.audio.ui.components.AlbumArtwork
import ua.nothing.audio.ui.components.DotMatrixText
import ua.nothing.audio.ui.components.MiniPlayer
import ua.nothing.audio.ui.theme.NothingBlack
import ua.nothing.audio.ui.theme.NothingBorder
import ua.nothing.audio.ui.theme.NothingDarkGray
import ua.nothing.audio.ui.theme.NothingGray
import ua.nothing.audio.ui.theme.NothingRed
import ua.nothing.audio.ui.theme.NothingWhite
import ua.nothing.audio.ui.theme.formatDuration

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: MusicViewModel) {
    val allTracks by viewModel.allTracks.collectAsState()
    val playlists by viewModel.playlists.collectAsState()
    val playbackState by viewModel.playbackState.collectAsState()
    val isImporting by viewModel.isImporting.collectAsState()
    val statusMessage by viewModel.statusMessage.collectAsState()

    var selectedTab by remember { mutableIntStateOf(0) } // 0 = Усі пісні, 1 = Плейлисти
    var showAddSourceSheet by remember { mutableStateOf(false) }
    var showFullPlayer by remember { mutableStateOf(false) }
    var trackForPlaylistDialog by remember { mutableStateOf<TrackEntity?>(null) }
    var openedPlaylist by remember { mutableStateOf<PlaylistSummary?>(null) }

    // Системний вибір аудіофайлів (SAF)
    val openFilesLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) {
            viewModel.importFiles(uris)
        }
    }

    // Системний вибір папки з музикою (SAF)
    val openFolderLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { treeUri ->
        if (treeUri != null) {
            viewModel.importFolder(treeUri)
        }
    }

    LaunchedEffect(statusMessage) {
        if (statusMessage != null) {
            delay(2500L)
            viewModel.clearStatusMessage()
        }
    }

    BackHandler(enabled = showFullPlayer || openedPlaylist != null) {
        if (showFullPlayer) {
            showFullPlayer = false
        } else if (openedPlaylist != null) {
            openedPlaylist = null
        }
    }

    if (showFullPlayer && playbackState.currentTrack != null) {
        FullPlayerScreen(
            playbackState = playbackState,
            onCollapse = { showFullPlayer = false },
            onPrevious = { viewModel.playerController.skipPrevious() },
            onTogglePlayPause = { viewModel.playerController.togglePlayPause() },
            onNext = { viewModel.playerController.skipNext() },
            onSeekTo = { viewModel.playerController.seekTo(it) },
            onCycleRepeat = { viewModel.playerController.cycleRepeatMode() },
            onToggleShuffle = { viewModel.playerController.toggleShuffle() },
            onJumpToQueueIndex = { viewModel.playerController.jumpToQueueIndex(it) },
            onMoveQueueItem = { from, to -> viewModel.playerController.moveQueueItem(from, to) },
            onRemoveQueueItem = { viewModel.playerController.removeQueueItem(it) }
        )
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NothingBlack)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // Верхній заголовок Nothing OS
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                DotMatrixText(
                    text = "NOTHING // AUDIO",
                    color = NothingWhite,
                    dotSize = 2.dp,
                    dotGap = 1.dp
                )
                Text(
                    text = "${allTracks.size} ТРЕКІВ • ${playlists.size} ПЛЕЙЛИСТІВ",
                    style = MaterialTheme.typography.labelSmall,
                    color = NothingGray
                )
            }

            if (statusMessage != null) {
                Box(
                    modifier = Modifier
                        .background(NothingDarkGray)
                        .border(1.dp, NothingRed)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = statusMessage.orEmpty(),
                        style = MaterialTheme.typography.labelSmall,
                        color = NothingWhite,
                        maxLines = 1
                    )
                }
            }
        }

        // Рівно дві вкладки («Усі пісні», «Плейлисти») + кнопка «+» праворуч
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            NothingTabButton(
                title = "УСІ ПІСНІ",
                selected = selectedTab == 0,
                onClick = {
                    selectedTab = 0
                    openedPlaylist = null
                },
                modifier = Modifier.weight(1f)
            )

            NothingTabButton(
                title = "ПЛЕЙЛИСТИ",
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                modifier = Modifier.weight(1f)
            )

            Box(
                modifier = Modifier
                    .size(46.dp)
                    .background(NothingRed)
                    .border(1.dp, NothingRed)
                    .clickable { showAddSourceSheet = true },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.Add,
                    contentDescription = "Додати музику",
                    tint = NothingWhite,
                    modifier = Modifier.size(24.dp)
                )
            }
        }

        if (isImporting) {
            Spacer(modifier = Modifier.height(8.dp))
            LinearProgressIndicator(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.dp)
                    .padding(horizontal = 16.dp),
                color = NothingRed,
                trackColor = NothingBorder
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Основний контент вкладок
        Box(modifier = Modifier.weight(1f)) {
            if (selectedTab == 0) {
                AllTracksTab(
                    tracks = allTracks,
                    currentTrackId = playbackState.currentTrack?.trackId,
                    isPlaying = playbackState.isPlaying,
                    onPlayTrack = { index -> viewModel.playAllTracks(index) },
                    onDeleteTrack = { track -> viewModel.deleteTrack(track) },
                    onAddToPlaylist = { track -> trackForPlaylistDialog = track },
                    onPlayNext = { track -> viewModel.playerController.playNext(track) },
                    onAppendQueue = { track -> viewModel.playerController.appendToQueue(track) }
                )
            } else {
                val activePlaylist = openedPlaylist
                if (activePlaylist == null) {
                    PlaylistsTab(
                        playlists = playlists,
                        onCreatePlaylist = { name -> viewModel.createPlaylist(name) },
                        onOpenPlaylist = { playlist -> openedPlaylist = playlist },
                        onPlayPlaylist = { playlist -> viewModel.playPlaylist(playlist.id, 0) },
                        onDeletePlaylist = { playlist -> viewModel.deletePlaylist(playlist.id) }
                    )
                } else {
                    PlaylistDetailView(
                        playlist = activePlaylist,
                        allTracks = allTracks,
                        viewModel = viewModel,
                        currentTrackId = playbackState.currentTrack?.trackId,
                        isPlaying = playbackState.isPlaying,
                        onBack = { openedPlaylist = null }
                    )
                }
            }
        }

        // Компактний чорний міні-плеєр знизу екрана
        if (playbackState.currentTrack != null) {
            MiniPlayer(
                playbackState = playbackState,
                onOpenFullPlayer = { showFullPlayer = true },
                onPrevious = { viewModel.playerController.skipPrevious() },
                onTogglePlayPause = { viewModel.playerController.togglePlayPause() },
                onNext = { viewModel.playerController.skipNext() },
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
            )
        }
    }

    // Діалог вибору джерела додавання файлів / папки через "+"
    if (showAddSourceSheet) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = { showAddSourceSheet = false },
            sheetState = sheetState,
            shape = RectangleShape,
            containerColor = NothingBlack,
            contentColor = NothingWhite,
            dragHandle = null
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(NothingBlack)
                    .border(1.dp, NothingBorder)
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                DotMatrixText(
                    text = "ДОДАТИ АУДІО",
                    color = NothingWhite,
                    dotSize = 2.dp,
                    dotGap = 1.dp
                )
                Text(
                    text = "Виберіть локальні аудіофайли або цілу папку через системний провідник Android.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = NothingGray
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(NothingBlack)
                        .border(1.dp, NothingBorder)
                        .clickable {
                            showAddSourceSheet = false
                            openFilesLauncher.launch(arrayOf("audio/*"))
                        }
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.MusicNote,
                        contentDescription = null,
                        tint = NothingRed
                    )
                    Column {
                        Text(
                            text = "ВИБРАТИ АУДІОФАЙЛИ",
                            style = MaterialTheme.typography.labelLarge,
                            color = NothingWhite
                        )
                        Text(
                            text = "MP3, FLAC, WAV, OGG, M4A, OPUS",
                            style = MaterialTheme.typography.labelSmall,
                            color = NothingGray
                        )
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(NothingBlack)
                        .border(1.dp, NothingBorder)
                        .clickable {
                            showAddSourceSheet = false
                            openFolderLauncher.launch(null)
                        }
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.FolderOpen,
                        contentDescription = null,
                        tint = NothingRed
                    )
                    Column {
                        Text(
                            text = "ВИБРАТИ ПАПКУ",
                            style = MaterialTheme.typography.labelLarge,
                            color = NothingWhite
                        )
                        Text(
                            text = "Рекурсивний імпорт усіх аудіофайлів",
                            style = MaterialTheme.typography.labelSmall,
                            color = NothingGray
                        )
                    }
                }
            }
        }
    }

    // Діалог додавання треку в плейлист (через меню три крапки)
    val selectedTrackForPlaylist = trackForPlaylistDialog
    if (selectedTrackForPlaylist != null) {
        AddTrackToPlaylistDialog(
            track = selectedTrackForPlaylist,
            playlists = playlists,
            onDismiss = { trackForPlaylistDialog = null },
            onSelectPlaylist = { playlistId ->
                viewModel.addTrackToPlaylist(playlistId, selectedTrackForPlaylist.id)
                trackForPlaylistDialog = null
            },
            onCreateAndAdd = { newName ->
                viewModel.createPlaylist(newName)
            }
        )
    }
}

@Composable
private fun NothingTabButton(
    title: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .height(46.dp)
            .background(if (selected) NothingWhite else NothingBlack)
            .border(1.dp, if (selected) NothingWhite else NothingBorder)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.labelLarge,
            color = if (selected) NothingBlack else NothingWhite
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AllTracksTab(
    tracks: List<TrackEntity>,
    currentTrackId: Long?,
    isPlaying: Boolean,
    onPlayTrack: (Int) -> Unit,
    onDeleteTrack: (TrackEntity) -> Unit,
    onAddToPlaylist: (TrackEntity) -> Unit,
    onPlayNext: (TrackEntity) -> Unit,
    onAppendQueue: (TrackEntity) -> Unit
) {
    if (tracks.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
                .border(1.dp, NothingBorder),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                DotMatrixText(
                    text = "СПИСОК ПОРОЖНІЙ",
                    color = NothingWhite,
                    dotSize = 2.5.dp,
                    dotGap = 1.dp
                )
                Text(
                    text = "Натисніть + у правому верхньому куті,\nщоб додати локальні треки або папку.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = NothingGray
                )
            }
        }
        return
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        itemsIndexed(
            items = tracks,
            key = { _, track -> track.id }
        ) { index, track ->
            val dismissState = rememberSwipeToDismissBoxState()

            LaunchedEffect(dismissState.currentValue) {
                if (dismissState.currentValue == SwipeToDismissBoxValue.EndToStart) {
                    onDeleteTrack(track)
                }
            }

            SwipeToDismissBox(
                state = dismissState,
                enableDismissFromStartToEnd = false,
                enableDismissFromEndToStart = true,
                backgroundContent = {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(NothingRed)
                            .border(1.dp, NothingRed)
                            .padding(horizontal = 20.dp),
                        contentAlignment = Alignment.CenterEnd
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "ВИДАЛИТИ",
                                style = MaterialTheme.typography.labelLarge,
                                color = NothingWhite
                            )
                            Icon(
                                imageVector = Icons.Filled.Delete,
                                contentDescription = "Видалити",
                                tint = NothingWhite
                            )
                        }
                    }
                }
            ) {
                TrackRowItem(
                    index = index,
                    track = track,
                    isCurrent = track.id == currentTrackId,
                    isPlaying = track.id == currentTrackId && isPlaying,
                    onClick = { onPlayTrack(index) },
                    onAddToPlaylist = { onAddToPlaylist(track) },
                    onPlayNext = { onPlayNext(track) },
                    onAppendQueue = { onAppendQueue(track) },
                    onDelete = { onDeleteTrack(track) }
                )
            }
        }
    }
}

@Composable
private fun TrackRowItem(
    index: Int,
    track: TrackEntity,
    isCurrent: Boolean,
    isPlaying: Boolean,
    onClick: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onPlayNext: () -> Unit,
    onAppendQueue: () -> Unit,
    onDelete: () -> Unit
) {
    var menuExpanded by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(NothingBlack)
            .border(1.dp, if (isCurrent) NothingRed else NothingBorder)
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            text = "%02d".format(index + 1),
            style = MaterialTheme.typography.labelLarge,
            color = if (isCurrent) NothingRed else NothingGray,
            modifier = Modifier.width(26.dp)
        )

        AlbumArtwork(
            artworkPath = track.artworkPath,
            modifier = Modifier.size(46.dp),
            isActiveTrack = isPlaying
        )

        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Text(
                text = track.title,
                style = MaterialTheme.typography.titleMedium,
                color = if (isCurrent) NothingRed else NothingWhite,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "${track.artist} • ${formatDuration(track.durationMs)}",
                style = MaterialTheme.typography.bodyMedium,
                color = NothingGray,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Box {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clickable { menuExpanded = true },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.MoreVert,
                    contentDescription = "Меню треку",
                    tint = NothingWhite,
                    modifier = Modifier.size(20.dp)
                )
            }

            DropdownMenu(
                expanded = menuExpanded,
                onDismissRequest = { menuExpanded = false },
                shape = RectangleShape,
                containerColor = NothingDarkGray
            ) {
                DropdownMenuItem(
                    text = {
                        Text(
                            text = "Додати в плейлист",
                            style = MaterialTheme.typography.bodyLarge,
                            color = NothingWhite
                        )
                    },
                    onClick = {
                        menuExpanded = false
                        onAddToPlaylist()
                    }
                )
                DropdownMenuItem(
                    text = {
                        Text(
                            text = "Грати наступним",
                            style = MaterialTheme.typography.bodyLarge,
                            color = NothingWhite
                        )
                    },
                    onClick = {
                        menuExpanded = false
                        onPlayNext()
                    }
                )
                DropdownMenuItem(
                    text = {
                        Text(
                            text = "Додати в чергу",
                            style = MaterialTheme.typography.bodyLarge,
                            color = NothingWhite
                        )
                    },
                    onClick = {
                        menuExpanded = false
                        onAppendQueue()
                    }
                )
                DropdownMenuItem(
                    text = {
                        Text(
                            text = "Видалити зі списку",
                            style = MaterialTheme.typography.bodyLarge,
                            color = NothingRed
                        )
                    },
                    onClick = {
                        menuExpanded = false
                        onDelete()
                    }
                )
            }
        }
    }
}

@Composable
private fun PlaylistsTab(
    playlists: List<PlaylistSummary>,
    onCreatePlaylist: (String) -> Unit,
    onOpenPlaylist: (PlaylistSummary) -> Unit,
    onPlayPlaylist: (PlaylistSummary) -> Unit,
    onDeletePlaylist: (PlaylistSummary) -> Unit
) {
    var showCreateDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .background(NothingBlack)
                .border(1.dp, NothingWhite)
                .clickable { showCreateDialog = true },
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "+ СТВОРИТИ ПЛЕЙЛИСТ",
                style = MaterialTheme.typography.labelLarge,
                color = NothingWhite
            )
        }

        if (playlists.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .border(1.dp, NothingBorder),
                contentAlignment = Alignment.Center
            ) {
                DotMatrixText(
                    text = "НЕМАЄ ПЛЕЙЛИСТІВ",
                    color = NothingGray,
                    dotSize = 2.dp,
                    dotGap = 1.dp
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(
                    items = playlists,
                    key = { it.id }
                ) { playlist ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(NothingBlack)
                            .border(1.dp, NothingBorder)
                            .clickable { onOpenPlaylist(playlist) }
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = playlist.name.uppercase(),
                                style = MaterialTheme.typography.titleMedium,
                                color = NothingWhite,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${playlist.trackCount} ТРЕКІВ",
                                style = MaterialTheme.typography.labelSmall,
                                color = NothingGray
                            )
                        }

                        if (playlist.trackCount > 0) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .background(NothingRed)
                                    .clickable { onPlayPlaylist(playlist) },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.PlayArrow,
                                    contentDescription = "Відтворити плейлист",
                                    tint = NothingWhite
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .border(1.dp, NothingBorder)
                                .clickable { onDeletePlaylist(playlist) },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Delete,
                                contentDescription = "Видалити плейлист",
                                tint = NothingGray,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        CreatePlaylistDialog(
            onDismiss = { showCreateDialog = false },
            onConfirm = { name ->
                onCreatePlaylist(name)
                showCreateDialog = false
            }
        )
    }
}

@Composable
private fun PlaylistDetailView(
    playlist: PlaylistSummary,
    allTracks: List<TrackEntity>,
    viewModel: MusicViewModel,
    currentTrackId: Long?,
    isPlaying: Boolean,
    onBack: () -> Unit
) {
    val playlistTracks by viewModel.observePlaylistTracks(playlist.id).collectAsState(initial = emptyList())
    var showSelectTracksDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .border(1.dp, NothingBorder)
                    .clickable { onBack() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Назад",
                    tint = NothingWhite
                )
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = playlist.name.uppercase(),
                    style = MaterialTheme.typography.titleLarge,
                    color = NothingWhite,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "${playlistTracks.size} ТРЕКІВ",
                    style = MaterialTheme.typography.labelSmall,
                    color = NothingGray
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp)
                    .background(if (playlistTracks.isNotEmpty()) NothingRed else NothingDarkGray)
                    .clickable(enabled = playlistTracks.isNotEmpty()) {
                        viewModel.playPlaylist(playlist.id, 0)
                    },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "▶ ВІДТВОРИТИ",
                    style = MaterialTheme.typography.labelLarge,
                    color = NothingWhite
                )
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp)
                    .border(1.dp, NothingWhite)
                    .clickable { showSelectTracksDialog = true },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "+ ДОДАТИ ТРЕКИ",
                    style = MaterialTheme.typography.labelLarge,
                    color = NothingWhite
                )
            }
        }

        if (playlistTracks.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .border(1.dp, NothingBorder),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "ПЛЕЙЛИСТ ПОРОЖНІЙ",
                    style = MaterialTheme.typography.bodyMedium,
                    color = NothingGray
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                itemsIndexed(
                    items = playlistTracks,
                    key = { _, track -> track.id }
                ) { index, track ->
                    val isCurrent = track.id == currentTrackId
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(NothingBlack)
                            .border(1.dp, if (isCurrent) NothingRed else NothingBorder)
                            .clickable { viewModel.playPlaylist(playlist.id, index) }
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "%02d".format(index + 1),
                            style = MaterialTheme.typography.labelLarge,
                            color = if (isCurrent) NothingRed else NothingGray
                        )
                        AlbumArtwork(
                            artworkPath = track.artworkPath,
                            modifier = Modifier.size(42.dp),
                            isActiveTrack = isCurrent && isPlaying
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = track.title,
                                style = MaterialTheme.typography.titleMedium,
                                color = if (isCurrent) NothingRed else NothingWhite,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${track.artist} • ${formatDuration(track.durationMs)}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = NothingGray,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clickable {
                                    viewModel.removeTrackFromPlaylist(playlist.id, track.id)
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Delete,
                                contentDescription = "Прибрати з плейлиста",
                                tint = NothingGray,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    if (showSelectTracksDialog) {
        val existingIds = remember(playlistTracks) { playlistTracks.map { it.id }.toSet() }
        val availableTracks = remember(allTracks, existingIds) {
            allTracks.filter { it.id !in existingIds }
        }
        val selectedIds = remember { mutableStateListOf<Long>() }

        AlertDialog(
            onDismissRequest = { showSelectTracksDialog = false },
            shape = RectangleShape,
            containerColor = NothingDarkGray,
            titleContentColor = NothingWhite,
            textContentColor = NothingWhite,
            title = {
                Text(
                    text = "ДОДАТИ ТРЕКИ У ПЛЕЙЛИСТ",
                    style = MaterialTheme.typography.titleMedium
                )
            },
            text = {
                if (availableTracks.isEmpty()) {
                    Text(
                        text = "Усі доступні треки вже додано до цього плейлиста.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = NothingGray
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier.height(320.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(availableTracks, key = { it.id }) { track ->
                            val checked = track.id in selectedIds
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, if (checked) NothingRed else NothingBorder)
                                    .clickable {
                                        if (checked) selectedIds.remove(track.id)
                                        else selectedIds.add(track.id)
                                    }
                                    .padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = checked,
                                    onCheckedChange = {
                                        if (checked) selectedIds.remove(track.id)
                                        else selectedIds.add(track.id)
                                    },
                                    colors = CheckboxDefaults.colors(
                                        checkedColor = NothingRed,
                                        uncheckedColor = NothingGray,
                                        checkmarkColor = NothingWhite
                                    )
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = track.title,
                                        style = MaterialTheme.typography.bodyLarge,
                                        color = NothingWhite,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = track.artist,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = NothingGray,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.addTracksToPlaylist(playlist.id, selectedIds.toList())
                        showSelectTracksDialog = false
                    }
                ) {
                    Text(
                        text = "ДОДАТИ (${selectedIds.size})",
                        color = NothingRed,
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { showSelectTracksDialog = false }) {
                    Text(
                        text = "СКАСУВАТИ",
                        color = NothingGray,
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }
        )
    }
}

@Composable
private fun CreatePlaylistDialog(
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var name by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RectangleShape,
        containerColor = NothingDarkGray,
        title = {
            Text(
                text = "НОВИЙ ПЛЕЙЛИСТ",
                style = MaterialTheme.typography.titleMedium,
                color = NothingWhite
            )
        },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                singleLine = true,
                placeholder = {
                    Text(
                        text = "Назва плейлиста...",
                        style = MaterialTheme.typography.bodyMedium,
                        color = NothingGray
                    )
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = NothingWhite,
                    unfocusedTextColor = NothingWhite,
                    focusedBorderColor = NothingRed,
                    unfocusedBorderColor = NothingBorder,
                    cursorColor = NothingRed
                ),
                shape = RectangleShape,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            TextButton(
                enabled = name.trim().isNotEmpty(),
                onClick = { onConfirm(name) }
            ) {
                Text(
                    text = "СТВОРИТИ",
                    color = if (name.trim().isNotEmpty()) NothingRed else NothingGray,
                    style = MaterialTheme.typography.labelLarge
                )
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(
                    text = "СКАСУВАТИ",
                    color = NothingGray,
                    style = MaterialTheme.typography.labelLarge
                )
            }
        }
    )
}

@Composable
private fun AddTrackToPlaylistDialog(
    track: TrackEntity,
    playlists: List<PlaylistSummary>,
    onDismiss: () -> Unit,
    onSelectPlaylist: (Long) -> Unit,
    onCreateAndAdd: (String) -> Unit
) {
    var newPlaylistName by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RectangleShape,
        containerColor = NothingDarkGray,
        title = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "ДОДАТИ В ПЛЕЙЛИСТ",
                    style = MaterialTheme.typography.titleMedium,
                    color = NothingWhite
                )
                Text(
                    text = track.title,
                    style = MaterialTheme.typography.bodyMedium,
                    color = NothingGray,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = newPlaylistName,
                        onValueChange = { newPlaylistName = it },
                        singleLine = true,
                        placeholder = {
                            Text(
                                text = "Новий плейлист...",
                                style = MaterialTheme.typography.bodyMedium,
                                color = NothingGray
                            )
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = NothingWhite,
                            unfocusedTextColor = NothingWhite,
                            focusedBorderColor = NothingRed,
                            unfocusedBorderColor = NothingBorder,
                            cursorColor = NothingRed
                        ),
                        shape = RectangleShape,
                        modifier = Modifier.weight(1f)
                    )

                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .background(if (newPlaylistName.trim().isNotEmpty()) NothingRed else NothingBlack)
                            .border(1.dp, NothingBorder)
                            .clickable(enabled = newPlaylistName.trim().isNotEmpty()) {
                                onCreateAndAdd(newPlaylistName)
                                newPlaylistName = ""
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Check,
                            contentDescription = "Створити",
                            tint = NothingWhite
                        )
                    }
                }

                if (playlists.isEmpty()) {
                    Text(
                        text = "Створіть перший плейлист вище.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = NothingGray
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier.height(220.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(playlists, key = { it.id }) { playlist ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(NothingBlack)
                                    .border(1.dp, NothingBorder)
                                    .clickable { onSelectPlaylist(playlist.id) }
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = playlist.name.uppercase(),
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = NothingWhite,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    text = "${playlist.trackCount}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = NothingRed
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(
                    text = "ЗАКРИТИ",
                    color = NothingGray,
                    style = MaterialTheme.typography.labelLarge
                )
            }
        }
    )
}
