package ua.nothing.audio.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import ua.nothing.audio.ui.theme.NothingWhite

/**
 * Аутентичний точково-матричний (5x7) рендерер заголовків, лічильників і таймерів у стилі Nothing OS.
 * Підтримує українську кирилицю, латиницю, цифри та розділові знаки.
 */
@Composable
fun DotMatrixText(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = NothingWhite,
    dotSize: Dp = 2.dp,
    dotGap: Dp = 1.dp,
    letterGapDots: Int = 1
) {
    val upper = text.uppercase()
    val colsPerGlyph = 5
    val rowsPerGlyph = 7

    val totalCols = if (upper.isEmpty()) 1 else {
        upper.length * colsPerGlyph + (upper.length - 1) * letterGapDots
    }

    val step = dotSize + dotGap
    val totalWidth = step * totalCols
    val totalHeight = step * rowsPerGlyph

    Canvas(modifier = modifier.size(width = totalWidth, height = totalHeight)) {
        val radiusPx = dotSize.toPx() / 2f
        val stepPx = step.toPx()

        upper.forEachIndexed { charIndex, ch ->
            val glyph = DotGlyphs.get(ch)
            val baseCol = charIndex * (colsPerGlyph + letterGapDots)
            for (r in 0 until rowsPerGlyph) {
                val rowMask = glyph[r]
                for (c in 0 until colsPerGlyph) {
                    val bit = (rowMask shr (colsPerGlyph - 1 - c)) and 1
                    if (bit == 1) {
                        val cx = (baseCol + c) * stepPx + radiusPx
                        val cy = r * stepPx + radiusPx
                        drawCircle(
                            color = color,
                            radius = radiusPx,
                            center = Offset(cx, cy)
                        )
                    }
                }
            }
        }
    }
}

private object DotGlyphs {
    private val SPACE = intArrayOf(0, 0, 0, 0, 0, 0, 0)

    private val glyphs: Map<Char, IntArray> = mapOf(
        ' ' to SPACE,
        // Цифри
        '0' to intArrayOf(0b01110, 0b10001, 0b10011, 0b10101, 0b11001, 0b10001, 0b01110),
        '1' to intArrayOf(0b00100, 0b01100, 0b00100, 0b00100, 0b00100, 0b00100, 0b01110),
        '2' to intArrayOf(0b01110, 0b10001, 0b00001, 0b00110, 0b01000, 0b10000, 0b11111),
        '3' to intArrayOf(0b11110, 0b00001, 0b00001, 0b01110, 0b00001, 0b00001, 0b11110),
        '4' to intArrayOf(0b00010, 0b00110, 0b01010, 0b10010, 0b11111, 0b00010, 0b00010),
        '5' to intArrayOf(0b11111, 0b10000, 0b11110, 0b00001, 0b00001, 0b10001, 0b01110),
        '6' to intArrayOf(0b00110, 0b01000, 0b10000, 0b11110, 0b10001, 0b10001, 0b01110),
        '7' to intArrayOf(0b11111, 0b00001, 0b00010, 0b00100, 0b01000, 0b01000, 0b01000),
        '8' to intArrayOf(0b01110, 0b10001, 0b10001, 0b01110, 0b10001, 0b10001, 0b01110),
        '9' to intArrayOf(0b01110, 0b10001, 0b10001, 0b01111, 0b00001, 0b00010, 0b01100),

        // Знаки
        ':' to intArrayOf(0b00000, 0b00100, 0b00100, 0b00000, 0b00100, 0b00100, 0b00000),
        '/' to intArrayOf(0b00001, 0b00010, 0b00010, 0b00100, 0b01000, 0b01000, 0b10000),
        '-' to intArrayOf(0b00000, 0b00000, 0b00000, 0b11111, 0b00000, 0b00000, 0b00000),
        '+' to intArrayOf(0b00000, 0b00100, 0b00100, 0b11111, 0b00100, 0b00100, 0b00000),
        '.' to intArrayOf(0b00000, 0b00000, 0b00000, 0b00000, 0b00000, 0b00110, 0b00110),
        ',' to intArrayOf(0b00000, 0b00000, 0b00000, 0b00000, 0b00100, 0b00100, 0b01000),
        '!' to intArrayOf(0b00100, 0b00100, 0b00100, 0b00100, 0b00100, 0b00000, 0b00100),
        '[' to intArrayOf(0b01110, 0b01000, 0b01000, 0b01000, 0b01000, 0b01000, 0b01110),
        ']' to intArrayOf(0b01110, 0b00010, 0b00010, 0b00010, 0b00010, 0b00010, 0b01110),
        '(' to intArrayOf(0b00010, 0b00100, 0b01000, 0b01000, 0b01000, 0b00100, 0b00010),
        ')' to intArrayOf(0b01000, 0b00100, 0b00010, 0b00010, 0b00010, 0b00100, 0b01000),
        '•' to intArrayOf(0b00000, 0b00000, 0b01110, 0b01110, 0b01110, 0b00000, 0b00000),

        // Латиниця
        'A' to intArrayOf(0b01110, 0b10001, 0b10001, 0b11111, 0b10001, 0b10001, 0b10001),
        'B' to intArrayOf(0b11110, 0b10001, 0b10001, 0b11110, 0b10001, 0b10001, 0b11110),
        'C' to intArrayOf(0b01110, 0b10001, 0b10000, 0b10000, 0b10000, 0b10001, 0b01110),
        'D' to intArrayOf(0b11100, 0b10010, 0b10001, 0b10001, 0b10001, 0b10010, 0b11100),
        'E' to intArrayOf(0b11111, 0b10000, 0b10000, 0b11110, 0b10000, 0b10000, 0b11111),
        'F' to intArrayOf(0b11111, 0b10000, 0b10000, 0b11110, 0b10000, 0b10000, 0b10000),
        'G' to intArrayOf(0b01110, 0b10001, 0b10000, 0b10111, 0b10001, 0b10001, 0b01111),
        'H' to intArrayOf(0b10001, 0b10001, 0b10001, 0b11111, 0b10001, 0b10001, 0b10001),
        'I' to intArrayOf(0b01110, 0b00100, 0b00100, 0b00100, 0b00100, 0b00100, 0b01110),
        'J' to intArrayOf(0b00111, 0b00010, 0b00010, 0b00010, 0b10010, 0b10010, 0b01100),
        'K' to intArrayOf(0b10001, 0b10010, 0b10100, 0b11000, 0b10100, 0b10010, 0b10001),
        'L' to intArrayOf(0b10000, 0b10000, 0b10000, 0b10000, 0b10000, 0b10000, 0b11111),
        'M' to intArrayOf(0b10001, 0b11011, 0b10101, 0b10101, 0b10001, 0b10001, 0b10001),
        'N' to intArrayOf(0b10001, 0b11001, 0b10101, 0b10011, 0b10001, 0b10001, 0b10001),
        'O' to intArrayOf(0b01110, 0b10001, 0b10001, 0b10001, 0b10001, 0b10001, 0b01110),
        'P' to intArrayOf(0b11110, 0b10001, 0b10001, 0b11110, 0b10000, 0b10000, 0b10000),
        'Q' to intArrayOf(0b01110, 0b10001, 0b10001, 0b10001, 0b10101, 0b10010, 0b01101),
        'R' to intArrayOf(0b11110, 0b10001, 0b10001, 0b11110, 0b10100, 0b10010, 0b10001),
        'S' to intArrayOf(0b01111, 0b10000, 0b10000, 0b01110, 0b00001, 0b00001, 0b11110),
        'T' to intArrayOf(0b11111, 0b00100, 0b00100, 0b00100, 0b00100, 0b00100, 0b00100),
        'U' to intArrayOf(0b10001, 0b10001, 0b10001, 0b10001, 0b10001, 0b10001, 0b01110),
        'V' to intArrayOf(0b10001, 0b10001, 0b10001, 0b10001, 0b10001, 0b01010, 0b00100),
        'W' to intArrayOf(0b10001, 0b10001, 0b10001, 0b10101, 0b10101, 0b11011, 0b10001),
        'X' to intArrayOf(0b10001, 0b10001, 0b01010, 0b00100, 0b01010, 0b10001, 0b10001),
        'Y' to intArrayOf(0b10001, 0b10001, 0b01010, 0b00100, 0b00100, 0b00100, 0b00100),
        'Z' to intArrayOf(0b11111, 0b00001, 0b00010, 0b00100, 0b01000, 0b10000, 0b11111),

        // Українська кирилиця
        'А' to intArrayOf(0b01110, 0b10001, 0b10001, 0b11111, 0b10001, 0b10001, 0b10001),
        'Б' to intArrayOf(0b11111, 0b10000, 0b10000, 0b11110, 0b10001, 0b10001, 0b11110),
        'В' to intArrayOf(0b11110, 0b10001, 0b10001, 0b11110, 0b10001, 0b10001, 0b11110),
        'Г' to intArrayOf(0b11111, 0b10000, 0b10000, 0b10000, 0b10000, 0b10000, 0b10000),
        'Ґ' to intArrayOf(0b11111, 0b10001, 0b10000, 0b10000, 0b10000, 0b10000, 0b10000),
        'Д' to intArrayOf(0b00110, 0b01010, 0b01010, 0b01010, 0b01010, 0b11111, 0b10001),
        'Е' to intArrayOf(0b11111, 0b10000, 0b10000, 0b11110, 0b10000, 0b10000, 0b11111),
        'Є' to intArrayOf(0b01110, 0b10001, 0b10000, 0b11110, 0b10000, 0b10001, 0b01110),
        'Ж' to intArrayOf(0b10101, 0b10101, 0b01110, 0b00100, 0b01110, 0b10101, 0b10101),
        'З' to intArrayOf(0b01110, 0b10001, 0b00001, 0b00110, 0b00001, 0b10001, 0b01110),
        'И' to intArrayOf(0b10001, 0b10001, 0b10011, 0b10101, 0b11001, 0b10001, 0b10001),
        'І' to intArrayOf(0b01110, 0b00100, 0b00100, 0b00100, 0b00100, 0b00100, 0b01110),
        'Ї' to intArrayOf(0b01010, 0b00000, 0b01110, 0b00100, 0b00100, 0b00100, 0b01110),
        'Й' to intArrayOf(0b01110, 0b10001, 0b10011, 0b10101, 0b11001, 0b10001, 0b10001),
        'К' to intArrayOf(0b10001, 0b10010, 0b10100, 0b11000, 0b10100, 0b10010, 0b10001),
        'Л' to intArrayOf(0b00111, 0b01001, 0b01001, 0b01001, 0b01001, 0b01001, 0b10001),
        'М' to intArrayOf(0b10001, 0b11011, 0b10101, 0b10101, 0b10001, 0b10001, 0b10001),
        'Н' to intArrayOf(0b10001, 0b10001, 0b10001, 0b11111, 0b10001, 0b10001, 0b10001),
        'О' to intArrayOf(0b01110, 0b10001, 0b10001, 0b10001, 0b10001, 0b10001, 0b01110),
        'П' to intArrayOf(0b11111, 0b10001, 0b10001, 0b10001, 0b10001, 0b10001, 0b10001),
        'Р' to intArrayOf(0b11110, 0b10001, 0b10001, 0b11110, 0b10000, 0b10000, 0b10000),
        'С' to intArrayOf(0b01110, 0b10001, 0b10000, 0b10000, 0b10000, 0b10001, 0b01110),
        'Т' to intArrayOf(0b11111, 0b00100, 0b00100, 0b00100, 0b00100, 0b00100, 0b00100),
        'У' to intArrayOf(0b10001, 0b10001, 0b10001, 0b01111, 0b00001, 0b10001, 0b01110),
        'Ф' to intArrayOf(0b00100, 0b01110, 0b10101, 0b10101, 0b10101, 0b01110, 0b00100),
        'Х' to intArrayOf(0b10001, 0b10001, 0b01010, 0b00100, 0b01010, 0b10001, 0b10001),
        'Ц' to intArrayOf(0b10010, 0b10010, 0b10010, 0b10010, 0b10010, 0b11111, 0b00001),
        'Ч' to intArrayOf(0b10001, 0b10001, 0b10001, 0b01111, 0b00001, 0b00001, 0b00001),
        'Ш' to intArrayOf(0b10101, 0b10101, 0b10101, 0b10101, 0b10101, 0b10101, 0b11111),
        'Щ' to intArrayOf(0b10101, 0b10101, 0b10101, 0b10101, 0b10101, 0b11111, 0b00001),
        'Ь' to intArrayOf(0b10000, 0b10000, 0b10000, 0b11110, 0b10001, 0b10001, 0b11110),
        'Ю' to intArrayOf(0b10010, 0b10101, 0b10101, 0b11101, 0b10101, 0b10101, 0b10010),
        'Я' to intArrayOf(0b01111, 0b10001, 0b10001, 0b01111, 0b00101, 0b01001, 0b10001)
    )

    fun get(ch: Char): IntArray = glyphs[ch] ?: SPACE
}
